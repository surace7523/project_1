<!DOCTYPE>


<?php $con = mysqli_connect("localhost","root","","ecom");?><!---direct connection with database of category---->

<html>
	<head>
		
		<title>Insert Product</title>


         
	</head>


 <body bgcolor="green">
	<form action="http://localhost/ecommerce/admin_area/insert_product.php"method="post" enctype="multipast/form-data">

		<table align="center" width="700" border="2" bgcolor="yellow">

			<tr align="center">
				
				<td colspan="8"><h2>Insert the products</h2></td>

		     </tr>


			<tr>
				
				<td align="right"><b>Product Title:</b></td>
				<td><input type="text" name="product_title"  /></td>

		     </tr>



		     <tr>
				
				<td align="right"><b>Product Category:</b></td>
				<td>
				  <select name="product_cat">
					<option>select category</option>
					<?php

						$get_cats = "select * from categories";

							$run_cats = mysqli_query($con, $get_cats);


							while($row_cats = mysqli_fetch_array($run_cats))
							{

								$cat_id = $row_cats['cat_id'];
								$cat_title = $row_cats['cat_title'];



								echo "<option>$cat_title</option>";




							 }

					?>
				  </select>
				</td>
		     </tr>
		     

		     <tr>
				
				<td align="right"><b>Product Brand:</b></td>
			      <td>
			      	<select name="product_brand">
					  <option>select Brand</option>


					  	<?php  

					  			$get_brands = "select * from brands";

								$run_brands = mysqli_query($con, $get_brands);


									while($row_brands = mysqli_fetch_array($run_brands)){

										$brand_id = $row_brands['brand_id'];
										$brand_title = $row_brands['brand_title'];



										echo "<option value= '$brand_id'>$brand_title</option>";




									}









					  		 ?>



		    	     </select>
		          </td>
		        </tr>
		     

		     <tr>
					
 						 <td align="right"><b>Product Image:</b></td>
						 <td><input type="file" name="fileName" ></td>
		

				

		     </tr>
		     

		     <tr>
				
				<td align="right"><b>Product Price:</b></td>
				<td><input type="text" name="product_price" value=""></td>

		     </tr>
		     

		     <tr>
				
				<td align="right"><b>Product Description:</b></td>
				<td>
					
					  <textarea  name="product_desc" cols="20" rows="10" ></textarea>
				</td>

		     </tr>
		     

		      <tr>
				
				<td align="right"><b>Product keywords:</b></td>
				<td><input type="text" name="product_keywords" value=""></td>

		     </tr>
		     
		     <tr>
				
				<td align="center"colspan="8"><input type="submit" name="insert_post" value="insert products now"></td>

		     </tr>
		     


		</table>


	</form>



</body>


</html>



<?php

if (isset($_POST['insert_post'])) {

////getting text from form field


$product_title= $_POST['product_title'];
$product_cat= $_POST['product_cat'];
$product_brand= $_POST['product_brand'];
$Product_price= $_POST['product_price'];
$product_desc= $_POST['product_desc'];
$product_keywords= $_POST['product_keywords'];

$fileName='';


if(isset($_GET[fileName])){


// $product_image=NULL;
 //$product_image = $_FILES['myimage']['name'];
//$product_image_tmp = $_FILES['product_image']['tmp_name'];
	$fileName = $_FILES['fileName']['name'];
    $tempName = $_FILES['fileName']['tmp_name'];
    
    if(isset($fileName))
    {
        if(!empty($fileName))
        {
            $location = "pics";
            if(move_uploaded_file($tempName, $location.$fileName))
            {
                echo 'File Uploaded';
            }
        }
    }


}



 echo $insert_product = "insert into products(product_cat,product_brand,product_title,product_price,product_desc,product_image,product_keywords) values ('$product_cat','$product_brand','$product_title','$Product_price','$product_desc','$fileName','$product_keywords')";

  echo "Variable 'a' is set.";

 



$con = mysqli_connect("localhost","root","","ecom");
$insert_pro = mysqli_query($con, $insert_product);


if($insert_pro){

	echo "<script>alert('inserted')</script>";
}

}


?>