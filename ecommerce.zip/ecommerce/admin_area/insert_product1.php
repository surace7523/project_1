<!DOCTYPE>

<html>
	<head>
		<title>Insert Product</title>
	</head>


<body bgcolor="green">

	<form action="ecommerce/admin_area/insert_product1.php" method="post" enctype="multipast/form-data">

		<table align="center" width="1000">

			<tr>
			  

		     </tr>


			 <tr>
				
				<td>Product Title:</td>
				<td><input type="text" name="products_Title">></td>>

		     </tr>>





		     <tr align="center">

		     	<td colspan="8"><input type="submit" name="insert" value="insert"></td>
		     </tr>



		</table>


	</form>



</body>


</html>