<!DOCTYPE html>

<?php include "function/functions.php";?>
<?php include "function/functions_1.php";?>
<?php include "function/get_productfunc.php";?>

<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Responsive Navbar</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
  </head>
 
 <body>

        <div class="main_wrapper">
                  <!---header starts---->
                    	<div class="header_wrapper"> 

    	         	      <img id ="logo"src="images/logo.jpg"/>
    		              <img id ="banner"src="images/logo.jpg"/>
   

    	                 </div>
    	         	<!---header ends>

    	        <--navigation bar r----> 		

    	        <div class="menubar">


    	        	<ul id="menu">

 						<li><a href="#">Home</a></li>
 						<li><a href="#">Products</a></li>
 						<li><a href="#">My Account</a></li>
 						<li><a href="#">Sign Up</a></li>
 						<li><a href="#">Shopping Cart</a></li>
 						<li><a href="#">Contact Us</a></li>

					</ul>


				    <div id="searchbox">

				    	<form method ="get" action="results.php" enctype="multipart/form-data">

				    		 <input type="text" name="user_query" placeholder="search Item" />
				    		 <input type="submit" name="search" value="search"/>

				    	</form>	 
				    		 

				    </div>	


    	        </div>
        
    	           <!--navigation bar ends ----> 

    	     <!----content wrapper starts-->   



    	     <div class="contentbar">
  					 <div id= "sidebar"> 
    	                 
    	       	             	<div id="sidebar_title">Vehicle Type</div>

    	       	                  <ul id="cats">
    	       	       	            <?php  getCats();?>

    	       	         	        </ul>	


    	       	       	        <div id="sidebar_title">Brands</div>

    	       	        	     <ul id="cats">

    	       	       	 		    <?php getBrands(); ?>


    	       	       	 	     </ul>	

    	                     </div>	


  				</div>
    	        <div class="content_wrapper">
  						
				

					<section>
    	             	


    	          		 <div id="content_area">

    	                    <div id="products_box">

                 	   			<?php getPro(); ?>

                 	   		 </div>

                                 
    	                  
    	                 </div>

    	             </section>


    	            	 </div>

    	        



     					 
    	        	 

     				 </div>



     				 	<div id="footer"> This is footer</div>

    	         </div>

           


                  


    	 </div>           


             <!------content wrapper ends------>
    	   
             





                     
   <footer>
   	<h1>fooooootttteerrr</h1>
   </footer>

    
       
           

     

    	        
         


      </body>



</html>


